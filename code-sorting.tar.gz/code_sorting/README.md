
建议阅读顺序:
algorithm.h -> Sort.cpp-> SortTest.cpp -> main.cpp -> Makefile -> 实验报告 -> plot.ipynb -> results_for_analysis

# 运行环境:
## 虚拟机
WSL2 Ubuntu
## 编程语言
c++
## 字符编码
utf-8
## 编译器版本
```
g++ -v:
COLLECT_GCC=g++
COLLECT_LTO_WRAPPER=/usr/lib/gcc/x86_64-linux-gnu/11/lto-wrapper
OFFLOAD_TARGET_NAMES=nvptx-none:amdgcn-amdhsa
OFFLOAD_TARGET_DEFAULT=1
Target: x86_64-linux-gnu
Thread model: posix
Supported LTO compression algorithms: zlib zstd
gcc version 11.4.0 (Ubuntu 11.4.0-1ubuntu1~22.04)
```
```
make -v:
GNU Make 4.3
Built for x86_64-pc-linux-gnu
Copyright (C) 1988-2020 Free Software Foundation, Inc.
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.
```

## 运行介绍

在解压路径下`make`生成可执行文件main, 运行`./main [vector_size] [num_repeat]`即可运行
vector_size表示问题规模n, num_repeat表示运行次数

<pre>
.
├── Blockquicksort.md
├── DualQuickSort.md
├── Makefile
├── README.md
├── Sort.cpp//排序算法源码(升序排序)
├── SortTest.cpp//排序测试(降序数组排序)
├── algorithm.h     //预定义h文件
├── main        //main函数
├── main.cpp    //打印vector
├── out.cpp
├── out.h
├── plot.ipynb
├── results_for_analysis
│   ├── 1.1_100000_10
│   │   ├── Sorting Algorithm Comparisons.png
│   │   ├── Sorting Algorithm Movements.png
│   │   ├── Sorting Algorithm Time Cost.png
│   │   └── time_cost.csv
│   ├── 1.1_10000_10
│   │   ├── Sorting Algorithm Comparisons.png
│   │   ├── Sorting Algorithm Movements.png
│   │   ├── Sorting Algorithm Time Cost.png
│   │   └── time_cost.csv
│   ├── 1.1_50000_10
│   │   ├── Sorting Algorithm Comparisons.png
│   │   └── time_cost.csv
│   ├── 1.1_5000_10
│   │   ├── Sorting Algorithm Comparisons.png
│   │   ├── Sorting Algorithm Movements.png
│   │   ├── Sorting Algorithm Time Cost.png
│   │   └── time_cost.csv
│   ├── 1.2_100000_10
│   │   ├── Sorting Algorithm Comparisons.png
│   │   ├── Sorting Algorithm Movements.png
│   │   ├── Sorting Algorithm Time Cost.png
│   │   └── time_cost.csv
│   ├── 1.3_5000000_10
│   │   ├── Sorting Algorithm Time Cost.png
│   │   └── time_cost.csv
│   ├── 1.6_10000000_10
│   │   ├── Sorting Algorithm Time Cost.png
│   │   └── time_cost.csv
│   ├── 1.6_1000000_10
│   │   ├── Sorting Algorithm Time Cost.png
│   │   └── time_cost.csv
│   ├── 1.6_100000_10
│   │   ├── Sorting Algorithm Time Cost.png
│   │   └── time_cost.csv
│   ├── 1.6_5000000_10
│   │   ├── Sorting Algorithm Time Cost.png
│   │   └── time_cost.csv
│   └── 1.7_100000000_10
│       ├── Sorting Algorithm Time Cost.png
│       └── time_cost.csv
└── time_cost.csv  //main函数的打印信息，统计用

</pre>

### 项目简介

1. 实现了常见的排序算法，包括选择排序、插入排序、希尔排序、归并排序、快速排序；
2. 实现了基于std::sort的排序算法的正确性测试和简单的降序数组排序检查。
3. 实现了排序算法的运行时间统计，并将统计结果输出到`time_cost.csv`文件中。
4. 其他csv是根据不同输入和不同排序算法生成的运行时间，关键操作次数（快速排序中只在hoare partition进行了统计）统计信息。
5. 根据不同的csv提供了画图脚本，可以生成不同排序算法的运行时间和关键操作次数的折线图，并保存到`time_cost.png`文件中。
6. 其他`*.png`图片是根据不同输入和不同排序算法生成的折线图，数据保存在同名csv文件中。
7. resluts_for_analysis目录下是实验数据csv和相应生成的png图片，可以用来分析排序算法的运行时间和关键操作次数。该文件目录的子文件目录命名格式一般为`*_*n_*m`第一个`*`指明该目录下的文件是关于实验报告中的哪一部分，第二个`*`指明问题规模和，第三个`*`指明重复测试次数。
8. `*.ipynb`是Jupyter Notebook文件，anaconda自带jupyter软件，或者可以在WSL中安装相应插件，或者复制到你熟悉的IDE中稍加修改即可运行，它提供了排序算法的实现和运行时间统计，并生成相应折线图。修改save_path变量即可读取目录下的csv文件并将图片保存到指定目录中。
9. 其他文件是项目的辅助文件，如Makefile、README.md等。
### tips:
vector_size设置较大请尽量注释NormalSortsTest函数他们是用来测试运行O(n^2)复杂度的排序算法的

为了保证运行效率，简单测试函数

`
SortTest.cpp::SortTest
SortTest.cpp::MSortTest
SortTest.cpp::QSortTest
SortTest.cpp::DQSortTest
main.cpp::chk_sort
`

等检查函数是默认注释掉了的

如果要测试大数据排序请自行修改
`algorithm.h::MAX_SIZE`和`main.cpp::vector_size`

`Sort.cpp`中的排序函数实现基本基于论文、教材和PPT如果有更巧妙的写法欢迎在评论区讨论

如果有任何问题请在讨论区评论，我会每晚查看一次。

