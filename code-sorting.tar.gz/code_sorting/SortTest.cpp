#include <iostream>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <stack>
#include <string>
#include <cstring>
#include "algorithm.h"
#include "out.h"

using namespace std;

void SortTest(void (*Sortfunt)(vector<int>&), int vector_size, bool OUT)
{
    vector<int> nums(vector_size);
    for (int i = 0; i < vector_size; i++)
        nums[i] = vector_size - 1 - i;
    Sortfunt(nums);
    if(OUT)out(nums);
    int flag = 0;
    for (int i = 0; i < vector_size; i++)
    {
        if (nums[i] != i)
            flag = 1;
    }
    if (flag)
        cout << "The code is wrong." << endl;
    else
        cout << "The code is correct." << endl;
}
//#define PARTION int ((*Par)(vector<int>&, int, int))  in algorithm.h
void QSortTest(void (*Sortfunt)(vector<int>&, int, int, PARTION), PARTION,int vector_size, bool OUT)
{
    vector<int> nums(vector_size);
    for (int i = 0; i < vector_size; i++)
        nums[i] = vector_size - 1 - i;
    Sortfunt(nums, 0, nums.size() - 1, Par);
    if(OUT)out(nums);
    int flag = 0;
    for (int i = 0; i < vector_size; i++)
    {
        if (nums[i] != i)
            flag = 1;
    }
    if (flag)
        cout << "The code is wrong." << endl;
    else
        cout << "The code is correct." << endl;
}

void DQSortTest(void (*Sortfunt)(vector<int>&, int, int, DUALPARTION), DUALPARTION,int vector_size, bool OUT)
{
    vector<int> nums(vector_size);
    for (int i = 0; i < vector_size; i++)
        nums[i] = vector_size - 1 - i;
    Sortfunt(nums, 0, nums.size() - 1, Par);
    if(OUT)out(nums);
    int flag = 0;
    for (int i = 0; i < vector_size; i++)
    {
        if (nums[i] != i)
            flag = 1;
    }
    if (flag)
        cout << "The code is wrong." << endl;
    else
        cout << "The code is correct." << endl;
}

void MSortTest(void (*Sortfunt)(vector<int>&, int, int), int vector_size, bool OUT)
{
    vector<int> nums(vector_size),tmp(vector_size);
    for (int i = 0; i < vector_size; i++)
        nums[i] = vector_size - 1 - i;
    Sortfunt(nums,0, nums.size() - 1);
    if(OUT)out(nums);
    int flag = 0;
    for (int i = 0; i < vector_size; i++)
    {
        if (nums[i] != i)
            flag = 1;
    }
    if (flag)
        cout << "The code is wrong." << endl;
    else
        cout << "The code is correct." << endl;
}
