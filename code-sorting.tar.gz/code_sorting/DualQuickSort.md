```
procedure BlockLomuto2(A[ℓ...r])
    n ← r − ℓ + 1;
    Require: n > 1, Pivots in A[ℓ] ≤A[r]
    p ← A[ℓ]; q ← A[r];
    integer block[0, . . . , B − 1]
    i, j, k ← ℓ + 1, num<p, num≤q ←0
    while k < r do
        t ← min(B, r − k);
        for c ← 0; c < t; c ← c + 1 do
            block[num≤q] ← c;
            num≤q ← num≤q + (q ≥ A[k + c]);
        k ← k + t;
        for c ← 0; c < num≤q; c ← c + 1 do
            Swap A[j + c] and A[k + block[c]]
        for c ← 0; c < num≤q; c ← c + 1 do
            block[num<p] ← c;
            num<p ← num<p + (p > A[j + c]);
        for c ← 0; c < num<p; c ← c + 1 do
            Swap A[i] and A[j + block[c]]
            i ← i + 1
        j ← j + num≤q;
        num<p, num≤q ← 0;
    Swap A[i −1] and A[1];
    Swap A[j] and A[n];
    return (i − 1, j);

procedure DualQuickSort(A[ℓ...r])
    if r − ℓ + 1 > 1 then
        choose pivots(A[ℓ...r]) //be sure that pivot in A[ℓ] ≤ A[r]
        (cutl,cuth) ← BlockLomuto2(A[ℓ...r])
        DualQuickSort(A[ℓ...cutl - 1])
        DualQuickSort(A[cutl + 1...cuth - 1])
        DualQuickSort(A[cuth + 1...r])
    
```