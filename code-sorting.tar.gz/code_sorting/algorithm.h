#include <iostream>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <stack>
#include <string>
#include <cstring>

using namespace std;

#define PARTION int ((*Par)(vector<int>&, int, int))
#define DUALPARTION pair<int, int> (*Par)(vector<int>&, int, int)
#define UP_BOUND 12345678
#define MAX_SIZE 100000000
#define BLOCK_SIZE 512

extern long long count_cmp, count_move;
//count_cmp记录elements和pivot的cmp次数，count_move记录元素赋值次数（swap记为三次）

void InsertSort(vector<int>&);
void SelectSort(vector<int>&);
void BubbleSort(vector<int>&);
void ShellSort(vector<int>&);
void MergeSort(vector<int>&,int,int);
int  Partition(vector<int>&,int,int);//1960 hoare
void Better_Pivot(vector<int>&, int, int);//select better pivot
int  Partition_Better_Pivot(vector<int>&,int,int);//1960 hoare + better pivot
int  Partition_Hole_Method(vector<int>&,int,int);//空穴法
int  Partition_Intro2Algorithm(vector<int>&,int,int);//前后指针法
int  Block_partition(vector<int>&,int,int);//Blockquicksort
int  Block_partition_futher_tuning(vector<int>&,int,int);//Blockquicksort + 论文 3.2节 优化
void QuickSort(vector<int>&,int,int,PARTION);
void choose_two_pivot(std::vector<int>&,int,int);//dualpivotquicksort 论文代码实现
pair<int,int>  DualPivot_partition(vector<int> &,int,int);
void DualPivotQuickSort(vector<int>&,int,int,DUALPARTION);


//SortTest.cpp中的简单测试函数main.cpp中提供了基于std::sort()的检查函数
void SortTest(void (*Sortfunt)(vector<int>&),int vecort_size = 10, bool OUT = true);
void QSortTest(void (*Sortfunt)(vector<int>&, int, int, PARTION), PARTION, int vecort_size = 10, bool OUT = true);
void MSortTest(void (*Sortfunt)(vector<int>&,int,int),int vecort_size = 10, bool OUT = true);
void DQSortTest(void (*Sortfunt)(vector<int>&, int, int, DUALPARTION), DUALPARTION, int vecort_size = 10, bool OUT = true);