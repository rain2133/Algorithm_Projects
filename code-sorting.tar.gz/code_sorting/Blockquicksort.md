```

def BlockQuicksort(A[ℓ, . . . , r]):
    if r > ℓ then
        pivot ← choosePivot(A[ℓ, . . . , r])
        cut ← BlockPartition(A[ℓ, . . . , r], pivot)
        BlockQuicksort(A[ℓ, . . . , cut −1])
        BlockQuicksort(A[cut+1, . . . , r])
    end if
end procedure
def BlockPartition(A[ℓ, . . . , r], pivot):
    integer offsetsL[0, . . . , B −1], offsetsR[0, . . . , B −1]
    integer startL, startR, numL, numR ← 0
    while r − ℓ + 1 > 2B do
        if numL = 0 then
            startL ← 0
            for i = 0, . . . , B −1 do
                offsetsL[numL] ← i
                numL += (pivot ≥ A[ℓ + i])
            end for
        end if
        if numR = 0 then
            startR ← 0
            for i = 0, . . . , B −1 do
                offsetsR[numR] ← i
                numR += (pivot ≤ A[r − i])
            end for
        end if
        num = min(numL, numR)
        for j = 0, . . . , num − 1 do
            swap(A[ℓ + offsetsL[startL + j]], A[r − offsetsR[startR + j]])
        end for
        numL, numR -= num; startL, startR += num
        if (numL = 0) then ℓ += B end if
        if (numR = 0) then r -= B end if
    end while
    compare and rearrange remaining elements //using normal partition
end procedure
```