#include <iostream>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <stack>
#include <string>
#include <cstring>
#include <functional>
#include <unordered_map>
#include <fstream>
#include "algorithm.h"
#include "out.h"

using namespace std;
struct Message{
    string name;
    double sumtime;
    long long count_cmp, count_move;
};
vector<Message> sortNandT;


// unordered_map 定义
unordered_map<void (*)(vector<int>&), string > NormalSortMap = {
    { (void (*)(vector<int>&))&InsertSort, "InsertSort" },
    { (void (*)(vector<int>&))&SelectSort, "SelectSort"},
    { (void (*)(vector<int>&))&BubbleSort, "BubbleSort" },
    { (void (*)(vector<int>&))&ShellSort,  "ShellSort"}
};

unordered_map< int (*)(vector<int>&,int,int) , string> QuitckSortPartitionMap = {
    { (int (*)(vector<int>&,int,int))&Partition,                    "hoare Partition" },
    { (int (*)(vector<int>&,int,int))&Partition_Better_Pivot,       "hoare Partition with better pivot" },
    { (int (*)(vector<int>&,int,int))&Partition_Hole_Method,        "Partition with hole method" },
    { (int (*)(vector<int>&,int,int))&Partition_Intro2Algorithm,    "Partition with intro2Algorithm" },
    { (int (*)(vector<int>&,int,int))Block_partition,               "Partition with Block for avoiding branch"},
    { (int (*)(vector<int>&,int,int))Block_partition_futher_tuning, "Partition with Block for avoiding branch(Further Tuning)"}
};

void chk_sort(vector<int> &a){
    int n = a.size();
    vector<int> b(n);
    for(int i = 0; i < n;i++)
        b[i] = a[i];
    sort(b.begin(),b.end());
    for(int i = 0; i < n;i++)
        if(a[i] != b[i]){
            printf("the sort algorithm is wrong,pls check it\n");
            exit(0);
        }
    printf("the sort algorithm is correct\n"); 
}
double sum_time = 0;

void NormalSortsTest(void (*Sortfunt)(vector<int>&),int vector_size,int num_repeat){    
    vector<int> vec(vector_size);
    count_cmp = 0, count_move = 0;
    for (int i = 0; i < num_repeat; i++){
        for (int j = 0; j < vector_size; j++)
            vec[j] = rand() % UP_BOUND;
        clock_t start_time, end_time;
        start_time = clock();
        Sortfunt(vec);
        end_time = clock();
        sum_time += (double)(end_time - start_time) / CLOCKS_PER_SEC;
        //若不检查排序算法正确性请注释
        // chk_sort(vec);
    }
    vec.clear();
    vec.shrink_to_fit();
    cout << "The average time of "<< NormalSortMap[Sortfunt] <<" is  " << sum_time / num_repeat << " s." << endl;
    sortNandT.push_back(Message{NormalSortMap[Sortfunt],sum_time / num_repeat,count_cmp / num_repeat,count_move / num_repeat});
    sum_time = 0;
}

void MergeSortsTest(void (*Sortfunt)(vector<int>&,int,int),int vector_size,int num_repeat){    
    vector<int> vec(vector_size);
    vector<int> tmp(vector_size); 
    count_cmp = 0, count_move = 0;
    for (int i = 0; i < num_repeat; i++){   
        for (int j = 0; j < vector_size; j++)
            vec[j] = rand() % UP_BOUND;
        clock_t start_time, end_time;
        start_time = clock();
        Sortfunt(vec, 0, vector_size - 1);
        end_time = clock();
        sum_time += (double)(end_time - start_time) / CLOCKS_PER_SEC;
        //若不检查排序算法正确性请注释
        // chk_sort(vec);
    }
    vec.clear();
    vec.shrink_to_fit();
    tmp.clear();
    tmp.shrink_to_fit();
    cout << "The average time of MergeSort is  " << sum_time / num_repeat << " s." << endl;
    sortNandT.push_back(Message{"MergeSort",sum_time / num_repeat,count_cmp / num_repeat,count_move / num_repeat});
    sum_time = 0;
}

void QuickSortsTest(PARTION,int vector_size,int num_repeat){
    vector<int> vec(vector_size);
    count_cmp = 0, count_move = 0;
    for (int i = 0; i < num_repeat; i++){
        for (int j = 0; j < vector_size; j++)
            vec[j] = rand() % UP_BOUND;
        clock_t start_time, end_time;
        start_time = clock();
        QuickSort(vec, 0, vector_size - 1, Par);
        end_time = clock();
        sum_time += (double)(end_time - start_time) / CLOCKS_PER_SEC;
        //若不检查排序算法正确性请注释
        // chk_sort(vec);
    }
    vec.clear();
    vec.shrink_to_fit();
    cout << "The average time of "<< QuitckSortPartitionMap[Par] <<" is  " << sum_time / num_repeat << " s." << endl;
    sortNandT.push_back(Message{QuitckSortPartitionMap[Par],sum_time / num_repeat,count_cmp / num_repeat,count_move / num_repeat});
    sum_time = 0;
}

void DualPivotQuickSortsTest(DUALPARTION,int vector_size,int num_repeat){
    vector<int> vec(vector_size);
    count_cmp = 0, count_move = 0;
    for (int i = 0; i < num_repeat; i++){
        for (int j = 0; j < vector_size; j++)
            vec[j] = rand() % UP_BOUND;
        clock_t start_time, end_time;
        start_time = clock();
        DualPivotQuickSort(vec, 0, vector_size - 1, Par);
        end_time = clock();
        sum_time += (double)(end_time - start_time) / CLOCKS_PER_SEC;
        //若不检查排序算法正确性请注释
        chk_sort(vec);
    }
    vec.clear();
    vec.shrink_to_fit();
    cout << "The average time of  DualPivotQuickSort is  " << sum_time / num_repeat << " s." << endl;
    sortNandT.push_back(Message{"Partition with Two Pivot",sum_time / num_repeat,count_cmp / num_repeat,count_move / num_repeat});
    sum_time = 0;
}

int main(int argc, char* argv[])
{   
    //接收两个参数，第一个参数为vector_size，第二个参数为num_repeat
    if(argc != 3){
        printf("Please input two parameters, the first parameter is vector_size, the second parameter is num_repeat\n");
        exit(0);
    }   
    srand(time(0));
    int vector_size;
    int num_repeat;
    vector_size = atoi(argv[1]);
    num_repeat = atoi(argv[2]);
    if(vector_size > MAX_SIZE){
        printf("vector_size is out of MAX_SIZE(in algorithm.h), please reset\n");
        exit(0);
    }
    // SortTest(InsertSort);
    // SortTest(SelectSort);
    // SortTest(BubbleSort);
    // SortTest(ShellSort);
    // MSortTest(MergeSort);
    // QSortTest(QuickSort, Partition);//hoare partition
    // QSortTest(QuickSort, Partition_Better_Pivot);
    // QSortTest(QuickSort, Partition_Hole_Method);
    // QSortTest(QuickSort, Partition_Intro2Algorithm);
    // QSortTest(QuickSort, Block_partition);
    // DQSortTest(DualPivotQuickSort, DualPivot_partition);

    if(vector_size > MAX_SIZE){
        printf("vector_size is out of MAX_SIZE(in algorithm.h), please reset\n");
        exit(0);
    }
    NormalSortsTest(InsertSort, vector_size, num_repeat);
    NormalSortsTest(SelectSort, vector_size, num_repeat);
    NormalSortsTest(BubbleSort, vector_size, num_repeat);
    NormalSortsTest(ShellSort, vector_size, num_repeat);
    MergeSortsTest(MergeSort, vector_size, num_repeat);
    QuickSortsTest(Partition, vector_size, num_repeat);
    QuickSortsTest(Partition_Better_Pivot, vector_size, num_repeat);
    QuickSortsTest(Partition_Hole_Method, vector_size, num_repeat);
    QuickSortsTest(Partition_Intro2Algorithm, vector_size, num_repeat);
    QuickSortsTest(Block_partition, vector_size, num_repeat);
    QuickSortsTest(Block_partition_futher_tuning, vector_size, num_repeat);
    DualPivotQuickSortsTest(DualPivot_partition, vector_size, num_repeat);
    ofstream fout("time_cost.csv");
    fout << "sort_name,ave_ex_time,cmp_ct,mov_ct\n";
    for(auto NaT : sortNandT)
       fout << NaT.name << ',' << NaT.sumtime << ',' << NaT.count_cmp << ',' << NaT.count_move << '\n';
    sortNandT.clear();
    sortNandT.shrink_to_fit();
    return 0;
}
