#include <iostream>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <stack>
#include <string>
#include <cstring>
#include "algorithm.h"
#include "out.h"

using namespace std;

long long count_cmp, count_move;

//归并排序临时数组
vector<int> tmpa(MAX_SIZE);

//blockquicksort 的block 也用作 dualblockquicksort 的block
vector<int> offsetsL(BLOCK_SIZE), offsetsR(BLOCK_SIZE);

/*
function   : 对数组进行插入排序
param nums : 要排序的数组引用
return     : ---
*/
void InsertSort(vector<int> &a){
	int n = a.size();
	
	for (int i = 0; i < n; i++){
		int j = i, key = a[j];count_move++;
		while (j > 0 && a[j - 1] > key){count_cmp++;
			a[j] = a[j - 1];count_move++;
			j--;
		}
		a[j] = key;count_move++;
	}
}
void SelectSort(vector<int>& a){
	int n = a.size();
	for(int i = 0;i < n;i++){
		int seqindex = i;
		for(int j = i + 1;j < n;j++){
			count_cmp++;
			if(a[j] < a[seqindex]){
				seqindex = j;
			}
		}
		swap(a[i], a[seqindex]),count_move+=3;
	}
}
void BubbleSort(vector<int> &a){
	int n = a.size();
	for(int end = a.size() - 1; end > 0; end--){
            int newend = 0;
            for(int i = 0; i < end; i++){
				count_cmp++;
                if(a[i] > a[i+1]){
                    swap(a[i], a[i + 1]);count_move+=3;
                    newend = i+1;
                }
            }
            end = newend;
        }
}

void ShellSort(vector<int> &a){
	int n = a.size();
	int h = 1;
  	while (h < n / 3) {
    	h = 3 * h + 1;
  	}
	while (h >= 1) {
		for (int i = h; i < n; i++) {
			for (int j = i; j >= h && a[j] < a[j - h]; j -= h) {
				swap(a[j], a[j - h]),count_cmp++;count_move+=3;
			}
		}
		h = h / 3;
	}
}

void MergeSort(vector<int> &a,int l, int r){
	if(l >= r) return;
	int mid = l + r >> 1, p = l,i,j;
	MergeSort(a,l, mid);
	MergeSort(a,mid + 1,r);
	for(i = l,j = mid + 1;i <= mid && j <= r;){//合并区间
		count_cmp++;count_move++;
		if(a[i] <= a[j])
			tmpa[p++] = a[i++];
		else
			tmpa[p++] = a[j++];
	}
	while(i <= mid)tmpa[p++] = a[i++],count_move++;
	while(j <= r)tmpa[p++] = a[j++],count_move++;
	for(int i = l;i <= r;i++)a[i] = tmpa[i];
}

int Partition(vector<int> &a,int p, int r){//hoare
	int x = a[p],i = p,j = r + 1;
	while(i < j){
		for(j--;a[j] >= x && j >  p;j--)count_cmp++;
		for(i++;a[i] <= x && i <= r;i++)count_cmp++;
		if(i < j)
			swap(a[i], a[j]),count_move+=3;
	}
	swap(a[p], a[j]),count_move+=3;
	return j;
}

void Better_Pivot(vector<int>& a, int p, int r){
	int mid = p + ((r - p) >> 1);
    //使用三数取中法选择基准值 
    if (a[mid] > a[r])
        swap(a[mid],a[r]);
    if (a[p] > a[r])
        swap(a[p],a[r]);
    if (a[mid] > a[p])
        swap(a[mid],a[p]);
}

int Partition_Better_Pivot(vector<int>& a, int p, int r){//hoare partition + better pivot
	Better_Pivot(a, p, r);
	int x = a[p],i = p,j = r + 1;
	// printf("pb:i %d j %d\n", i, j);
	// for(int k = p; k <= r;k++)printf("%d ",a[k]);printf("\n");
	while(i < j){
		for(j--;a[j] >= x && j >  p;j--);
		for(i++;a[i] <= x && i <= r;i++);
		// printf("swap:i %d j %d\n", i, j);
		if(i < j)
			swap(a[i], a[j]);
	}
	// printf("swap:p %d j %d\n", p, j);
	swap(a[p], a[j]);
	return j;
}

int  Partition_Hole_Method(vector<int>& a, int p, int r){//空穴法
	Better_Pivot(a, p, r);
	int x = a[p],i = p,j = r, holeid = p;
	// for(int k = p; k <= r;k++)printf("%d ",a[k]);printf("\n");
	while(i < j){
		//相遇则跳出循环
		for(;a[j] >= x && j > i;j--);
		// printf(" = :hole %d j %d\n", holeid, j);
		a[holeid] = a[j];holeid = j;
		for(;a[i] <= x && i < j;i++);
		// printf(" = :hole %d i %d\n", holeid, i);
		a[holeid] = a[i];holeid = i;
	}
	a[holeid] = x;
	return holeid;
}
int  Partition_Intro2Algorithm(vector<int>& a, int p, int r){//前后指针版
	Better_Pivot(a, p, r);
	
	int x = a[p],prev = p,curr = p + 1;
	while(curr <= r){
		if(a[curr] < x && ++prev != curr)//不连续 交换prev和curr指向的值
			swap(a[prev],a[curr]);
		++curr;
	}
	swap(a[p],a[prev]);
	return prev;
}

int Block_partition(vector<int>& a, int p, int r){
	Better_Pivot(a, p, r);
	int L = p + 1, R = r,x = a[p], i, j;
	int startL = 0, startR = 0, numL = 0, numR = 0;
	while(R - L + 1 > 2 * BLOCK_SIZE){
		if(numL == 0){	//fill left buffer
			startL = 0;
			for(i = 0; i < BLOCK_SIZE ; i++){
				offsetsL[numL] = i;
				numL += (x <= a[L + i]);
			}
		}
		if(numR == 0){	//fill right buffer
			startR = 0;
			for(i = 0; i < BLOCK_SIZE ; i++){
				offsetsR[numR] = i;
				numR += (x >= a[R - i]);
			}
		}
		int num = min(numL, numR);
		for(j = 0; j < num;j++)
			swap(a[L + offsetsL[startL + j]],a[R - offsetsR[startR + j]]);
		numL -= num, numR -= num;
		startL += num, startR += num;
		L += BLOCK_SIZE * (numL == 0);
		R -= BLOCK_SIZE * (numR == 0);
	}
	//rearrange remaining elements hoare partition

	i = L - 1,j = R + 1;
	while(i < j){
		for(j--;a[j] >= x && j >= L;j--);
		for(i++;a[i] <= x && i <= R;i++);
		if(i < j)
			swap(a[i], a[j]);
	}
	swap(a[p], a[j]);
	return j;
}

int Block_partition_futher_tuning(vector<int>& a, int p, int r){
	Better_Pivot(a, p, r);
	int L = p + 1, R = r,x = a[p], i, j;
	int startL = 0, startR = 0, numL = 0, numR = 0;
	while(R - L + 1 > 2 * BLOCK_SIZE){
		//3.2 优化循环展开 loop unrolling
		if(numL == 0){	//fill left buffer
			startL = 0;
			for(i = 0; i < BLOCK_SIZE ; i += 8){
				offsetsL[numL] = i;
				numL += (x <= a[L + i]);
				offsetsL[numL] = i + 1;
				numL += (x <= a[L + i + 1]);
				offsetsL[numL] = i + 2;
				numL += (x <= a[L + i + 2]);
				offsetsL[numL] = i + 3;
				numL += (x <= a[L + i + 3]);
				offsetsL[numL] = i + 4;
				numL += (x <= a[L + i + 4]);
				offsetsL[numL] = i + 5;
				numL += (x <= a[L + i + 5]);
				offsetsL[numL] = i + 6;
				numL += (x <= a[L + i + 6]);
				offsetsL[numL] = i + 7;
				numL += (x <= a[L + i + 7]);
			}
		}
		if(numR == 0){	//fill right buffer
			startR = 0;
			for(i = 0; i < BLOCK_SIZE ; i += 8){
				offsetsR[numR] = i;
				numR += (x >= a[R - i]);
				offsetsR[numR] = i + 1;
				numR += (x >= a[R - i - 1]);
				offsetsR[numR] = i + 2;
				numR += (x >= a[R - i - 2]);
				offsetsR[numR] = i + 3;
				numR += (x >= a[R - i - 3]);
				offsetsR[numR] = i + 4;
				numR += (x >= a[R - i - 4]);
				offsetsR[numR] = i + 5;
				numR += (x >= a[R - i - 5]);
				offsetsR[numR] = i + 6;
				numR += (x >= a[R - i - 6]);
				offsetsR[numR] = i + 7;
				numR += (x >= a[R - i - 7]);
			}
		}
		int num = min(numL, numR);

		//优化swap 论文3.2 Cyclic permutations instead of swaps
		int tmp = a[L + offsetsL[startL]];
		a[L + offsetsL[startL]] = a[R - offsetsR[startR]];
		for(j = 1; j < num;j++)
			a[R - offsetsR[startR + j - 1]] = a[L + offsetsL[startL + j]],
			a[L + offsetsL[startL + j]]     = a[R - offsetsR[startR + j]];
		a[R - offsetsR[startR + num - 1]] = tmp;
		numL -= num, numR -= num;
		startL += num, startR += num;
		L += BLOCK_SIZE * (numL == 0);
		R -= BLOCK_SIZE * (numR == 0);

	}
	i = L - 1,j = R + 1;
	while(i < j){
		for(j--;a[j] >= x && j >= L;j--);
		for(i++;a[i] <= x && i <= R;i++);
		if(i < j)
			swap(a[i], a[j]);
	}
	swap(a[p], a[j]);
	return j;//rearrange remaining elements
}

void choose_two_pivot(std::vector<int> &a, int p, int r){
	//a[p] <= a[r]
	int third = (r - p + 1) / 3;
	swap(a[p + third], a[p]);
	swap(a[r - third], a[r]);
	if(a[p] > a[r])
		swap(a[p],a[r]);
}
pair<int, int> DualPivot_partition(vector<int>& a, int p, int r){
	int x = a[p], y = a[r], n = r - p + 1;
	int i = p + 1,j = p + 1,k = p + 1, numlessp = 0, numnomoreq = 0;
	while(k < r){
		int t = min(BLOCK_SIZE, r - k), c;
		for(c = 0; c < t;c++)
			offsetsL[numnomoreq] = c,
			numnomoreq += (y >= a[k + c]);

		for(c = 0; c < numnomoreq;c++)
			swap(a[j + c], a[k + offsetsL[c]]);
		//我尝试优化swap但是会错，百思不得其解，大神帮我看看
		// int tmp = a[j];
		// if(numnomoreq > 0){
		// 	a[j] = a[k + offsetsL[0]];
		// 	for(c = 1; c < numnomoreq;c++)
		// 		a[k + offsetsL[c - 1]] = a[j + c],
		// 		a[j + c]               = a[k + offsetsL[c]];
		// 	a[k + offsetsL[numnomoreq - 1]] = tmp;
		// }
		k += t;
		for(c = 0;c < numnomoreq;c++)
			offsetsL[numlessp] = c,
			numlessp += (x > a[j + c]);
		for(c = 0;c < numlessp;c++)
			swap(a[i + c], a[j + offsetsL[c]]);
		// tmp = a[i];
		// if(numlessp > 0){
		// 	a[i] = a[j + offsetsL[0]];
		// 	for(c = 1;c < numlessp;c++)
		// 		a[j + offsetsL[c - 1]] = a[i + c],
		// 		a[i + c]               = a[j + offsetsL[c]];
		// 	a[j + offsetsL[numlessp - 1]] = tmp;
		// }
		
		i += numlessp;
		j += numnomoreq;
		numlessp = 0, numnomoreq = 0;
	}
	swap(a[i - 1], a[p]);
	swap(a[j], a[r]);
	return make_pair(i - 1,j);
}
void DualPivotQuickSort(vector<int>& a, int p, int r,pair<int, int> (*Par)(vector<int>&, int, int)){
	if(p >= r)return;
	choose_two_pivot(a, p, r);
	pair<int,int> pivots = Par(a, p, r);
	DualPivotQuickSort(a, p, pivots.first - 1, Par);
	DualPivotQuickSort(a, pivots.first + 1, pivots.second - 1, Par);
	DualPivotQuickSort(a, pivots.second + 1, r, Par);
}
void QuickSort(vector<int> &a,int p, int r,int (*Par)(vector<int>&, int, int)){
	if(p >= r) return;
	int q = Par(a, p, r);
	QuickSort(a, p, q - 1, Par);
	QuickSort(a, q + 1, r, Par);
}


